CUDA_VISIBLE_DEVICES=7 python main.py --save_results --save_models --save test_1117_ms_re
