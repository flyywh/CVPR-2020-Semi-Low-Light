CUDA_VISIBLE_DEVICES=5 python main_test.py --save_results --test_only --save test_1117_ms_re_v8_test --data_range 1-800/1-200 --save Semi_results 
